#include <bits/stdc++.h>

using namespace std;

typedef pair <int, int> pii;

const int maxn = 2e5 + 10, maxlog = 19, maxa = 60;
int n, test, q, suf[maxn], frank[maxn], rnk[maxlog][maxn], lcp[maxn], parent[maxn], l[maxn], r[maxn], curr, h, all, nxt[maxn][maxa];
pair <pii, int> p[maxn];
string s, t;

int get(char c) {
    return c >= 'a' ? c - 'a' + 26 : c - 'A';
}

void build_suf() {
    for (int i = 0; i < n; i++)
        rnk[0][i] = get(s[i]);
    for (int i = 1; i < maxlog; i++) {
        for (int j = 0; j < n; j++)
            p[j] = {{rnk[i - 1][j], (j + (1 << (i - 1)) < n ? rnk[i - 1][j + (1 << (i - 1))] : -1)}, j};
        sort (p, p + n);
        int currnk = 0;
        for (int j = 0; j < n; j++) {
            if (j && p[j - 1].first != p[j].first)
                currnk++;
            rnk[i][j] = currnk;
        }
    }
    for (int i = 0; i < n; i++)
        frank[i] = rnk[maxlog- 1][i];
    for (int i = 0; i < n; i++)
        suf[frank[i]] = i;
}
void build_lcp() {
    int len = 0;
    for (int i = 0; i < n; i++) {
        if (frank[i] == n - 1) {
            len = 0;
            continue;
        }
        int j = suf[frank[i] + 1];
        while (i + len < n && j + len < n && s[i + len]  == s[j + len])
            len++;
        lcp[frank[i]] = len;
        if (len) len--;
    }
}
void build_suffix_tree() {
    all = 1, h = 0, curr = 0;
    for (int i = 0; i < n; i++) {
        int st = suf[i];
        parent[all] = curr;
        l[all] = st + h;
        r[all] = n;
        curr = all++;
        h = n - st;
        while (curr && h - (r[curr] - l[curr]) >= lcp[i])
            h -= r[curr] - l[curr];
            curr = parent[curr];
        if (h > lcp[i]) {
            int dis = h - lcp[i];
            parent[all] = parent[curr];
            parent[curr] = all;
            l[all] = l[curr];
            r[all] = r[curr] - dis;
            l[curr] = r[curr] - dis;
            h = lcp[i];
            curr = all++;
        }
    }
    for (int i = 1; i < all; i++)
        nxt[parent[i]][get(s[l[i]])] = i;
    return;
}
int main() {
    ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
    cin >> test;
    while (test--) {
        memset(nxt, 0, sizeof(nxt));
        cin >> s >> q;
        n = s.size();
        build_suf();
        build_lcp();
        build_suffix_tree();
        while (q--) {
            cin >> t;
            bool flag = true;
            curr = 0;
            for (int i = 0, pos = 0, en = 0, se = t.size(); i < se; i++, pos++) {
                if (pos == en) {
                    if (nxt[curr][get(t[i])] == 0) {
                        flag = false;
                        break;
                    }
                    curr = nxt[curr][get(t[i])];
                    pos = l[curr];
                    en = r[curr];
                }
                if (t[i] != s[pos]) {
                    flag = false;
                    break;

                }
            }
            if (flag)
                cout << "y\n";
            else
                cout << "n\n";
        }
        return 0;
    }
}