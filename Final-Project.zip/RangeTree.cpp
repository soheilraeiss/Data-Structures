#include <bits/stdc++.h>
struct Interval {
    double low, high;
};

struct ITNode {
    Interval intvl;
    double max;
    ITNode *left, *right;
};

ITNode *newNode(Interval i) {
    ITNode *temp = new ITNode;
    temp->intvl = i;
    temp->max = i.high;
    temp->left = temp->right = nullptr;
    return temp;
}

bool doOverlap(Interval i1, Interval i2) {
    return (i1.low <= i2.high && i2.low <= i1.high);
}

ITNode *intervalInsert(ITNode *root, Interval i) {
    if (root == nullptr)
        return newNode(i);
    double l = root->intvl.low;
    if (i.low < l)
        root->left = intervalInsert(root->left, i);

    else
        root->right = intervalInsert(root->right, i);

    if (root->max < i.high)
        root->max = i.high;

    return root;
}

ITNode *intervalSearch(ITNode *root, Interval i) {
    if (root == nullptr)
        return nullptr;

    if (doOverlap(root->intvl, i))
        return root;

    if (root->left != nullptr && root->left->max >= i.low)
        return intervalSearch(root->left, i);

    return intervalSearch(root->right, i);
}

int main() {
    Interval intervals[] = {{15, 20}, {10, 30}, {17, 19},
                            {5, 20}, {12, 15}, {30, 40}};
    int n = sizeof(intervals) / sizeof(intervals[0]);
    ITNode *root = nullptr;

    for (int i = 0; i < n; i++)
        root = intervalInsert(root, intervals[i]);

    Interval x = {6, 7};

    std::cout << "Searching for interval [" << x.low << "," << x.high << "]" << std::endl;
    ITNode *res = intervalSearch(root, x);
    if (res == nullptr)
        std::cout << "No overlapping interval\n";
    else
        std::cout << "Overlaps with [" << res->intvl.low << ", " << res->intvl.high << "]\n";

    return 0;
}
