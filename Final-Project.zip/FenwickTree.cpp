#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

const int N = 1e6 + 10;
int n, bit[N];

inline ll get(int i) {
    ll sum = 0;
    for (; i; i -= (-i) & i)
        sum += bit[i];
    return sum;
}

inline void add(int i, int v) {
    for (; i <= n; i += (-i) & i)
        bit[i] += v;
}

// Function to get the sum of an interval [L, R)
inline int get(int L, int R) {
    return get(R - 1) - get(L - 1);
}

int main() {
    cout << "Enter the size of the array: ";
    cin >> n;
    vector<int> arr(n);
    memset(bit, 0, sizeof(bit));
    cout << "Enter the elements of the array: ";
    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
        add(i + 1, arr[i]); 
    }
    int L, R;
    cout << "Enter the interval [L, R): ";
    cin >> L >> R;
    cout << "Sum of elements in the interval [" << L << ", " << R << "): " << get(L, R) << endl;
    int index, newValue;
    cout << "Enter the index and new value to update: ";
    cin >> index >> newValue;
    int oldValue = arr[index - 1];
    arr[index - 1] = newValue;
    add(index, newValue - oldValue);
    return 0;
}
