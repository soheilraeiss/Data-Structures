#include <iostream>
#include <cmath>
#include <algorithm>
class MinMaxHeap {
public:
    int *H;
    int capacity;
    int size;
    MinMaxHeap(int n) {
        H = new int[n + 1];
        size = 0;
        capacity = n;
    }
    ~MinMaxHeap() {
        delete[] H;
    }
    int min() {
        if (size == 0)
            throw std::logic_error("Heap is empty");
        return H[1];
    }
    int max() {
        if (size == 0)
            throw std::logic_error("Heap is empty");
        else if (size == 1)
            return H[1];
        else if (size == 2)
            return H[2];
        else
            return std::max(H[2], H[3]);
    }
    void add(int x) {
        if (size == capacity)
            throw std::length_error("Heap is full");
        H[++size] = x;
        fixUp(size);
    }
    int removeMin() {
        if (size == 0)
            throw std::logic_error("Heap is empty");
        int min = H[1];
        H[1] = H[size--];
        fixDown(1);
        return min;
    }
    int removeMax() {
        if (size == 0)
            throw std::logic_error("Heap is empty");
        if (size == 1)
            return H[size--];
        int indexMax = (size == 2 || H[2] > H[3]) ? 2 : 3;
        int max = H[indexMax];
        H[indexMax] = H[size--];
        fixDown(indexMax);
        return max;
    }
private:
    bool isMinLevel(int i) {
        return (int)log2(i) % 2 == 0;
    }
    void fixUp(int i) {
        if (i > 1) {
            int p = i / 2;
            if (isMinLevel(i)) {
                if (H[i] > H[p]) {
                    std::swap(H[i], H[p]);
                    fixUpMax(p);
                } else {
                    fixUpMin(i);
                }
            } else {
                if (H[i] < H[p]) {
                    std::swap(H[i], H[p]);
                    fixUpMin(p);
                } else {
                    fixUpMax(i);
                }
            }
        }
    }
    void fixUpMin(int i) {
        while (i > 3) {
            int gp = i / 4;
            if (H[i] < H[gp]) {
                std::swap(H[i], H[gp]);
                i = gp;
            } else {
                break;
            }
        }
    }
    void fixUpMax(int i) {
        while (i > 3) {
            int gp = i / 4;
            if (H[i] > H[gp]) {
                std::swap(H[i], H[gp]);
                i = gp;
            } else {
                break;
            }
        }
    }
    void fixDown(int i) {
        if (isMinLevel(i)) {
            fixDownMin(i);
        } else {
            fixDownMax(i);
        }
    }
    void fixDownMin(int i) {
        while (i <= size) {
            int m = findSmallestChildOrGrandchild(i);
            if (m == -1) break;
            if (m <= size / 2) {
                if (H[m] < H[i]) {
                    std::swap(H[m], H[i]);
                }
                break;
            } else {
                if (H[m] < H[i]) {
                    std::swap(H[m], H[i]);
                    int parentM = m / 2;
                    if (H[m] > H[parentM]) {
                        std::swap(H[m], H[parentM]);
                    }
                    i = m;
                } else {
                    break;
                }
            }
        }
    }
    void fixDownMax(int i) {
        while (i <= size) {
            int m = findLargestChildOrGrandchild(i);
            if (m == -1) break;
            if (m <= size / 2) {
                if (H[m] > H[i]) {
                    std::swap(H[m], H[i]);
                }
                break;
            } else {
                if (H[m] > H[i]) {
                    std::swap(H[m], H[i]);
                    int parentM = m / 2;
                    if (H[m] < H[parentM]) {
                        std::swap(H[m], H[parentM]);
                    }
                    i = m;
                } else {
                    break;
                }
            }
        }
    }
    int findSmallestChildOrGrandchild(int i) {
        int leftChild = 2 * i;
        int rightChild = 2 * i + 1;
        int smallest = -1;
        if (leftChild <= size) {
            smallest = leftChild;
            if (rightChild <= size && H[rightChild] < H[smallest]) {
                smallest = rightChild;
            }
            for (int k = 0; k <= 3; ++k) {
                int grandchild = 2 * leftChild + k;
                if (grandchild <= size && H[grandchild] < H[smallest]) {
                    smallest = grandchild;
                }
            }
        }
        return smallest;
    }
    int findLargestChildOrGrandchild(int i) {
        int leftChild = 2 * i;
        int rightChild = 2 * i + 1;
        int largest = -1;
        if (leftChild <= size) {
            largest = leftChild;
            if (rightChild <= size && H[rightChild] > H[largest]) {
                largest = rightChild;
            }
            for (int k = 0; k <= 3; ++k) {
                int grandchild = 2 * leftChild + k;
                if (grandchild <= size && H[grandchild] > H[largest]) {
                    largest = grandchild;
                }
            }
        }
        return largest;
    }
};
int main() {
    MinMaxHeap heap(15);
    heap.add(10);
    heap.add(15);
    heap.add(30);
    heap.add(40);
    heap.add(50);
    heap.add(100);
    heap.add(40);
    std::cout << "Min: " << heap.min() << std::endl;
    std::cout << "Max: " << heap.max() << std::endl;
    std::cout << "Remove Min: " << heap.removeMin() << std::endl;
    std::cout << "Remove Max: " << heap.removeMax() << std::endl;
    std::cout << "Min: " << heap.min() << std::endl;
    std::cout << "Max: " << heap.max() << std::endl;
    return 0;
}
